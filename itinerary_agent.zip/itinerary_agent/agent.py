from google.adk.agents.llm_agent import Agent
from .instructions import ITINERARY_PROMPT
from .tools import tripadvisor_tool,google_maps_tool,weather_tool

root_agent = Agent(
    model="gemini-2.0-flash",
    name="itinerary_agent",
    instruction=ITINERARY_PROMPT,
    tools=[weather_tool,
           tripadvisor_tool,
           google_maps_tool
           ],
)